#!python
#!/usr/bin/env python

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.spinner import Spinner

Builder.load_string('''
<GridLayout>
    canvas.before:
        BorderImage:
            border: 10, 10, 10, 10
            source: 'plateau.jpg'
            pos: self.pos
            size: self.size

<RootWidget>
    GridLayout:
        size_hint: 1, 1
        pos_hint: {'center_x': .5, 'center_y': .5}
        rows:1

    #a faire pour chaque "Button" :
  	#- rajouter "btn" avant chaque ID de bouton
  	#- rajouter le "on_press" avec le bon ID en paramètre
  	#- rajouter la ligne de background_normal...

    Button:
        size_hint: .05, .05
		pos_hint: {'x':.075, 'y':.075}
		id:btn42
		on_press: root.changer_couleur(btn42)	
	    background_normal: 'img/btns/b0.png'
		

    Button:
        size_hint: .05, .05
		pos_hint: {'x':.325, 'y':.075}	
		id:btn41
		on_press: root.changer_couleur(btn41)	
	    background_normal: 'img/btns/b0.png'
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.48, 'y':.075}	
		id:43
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.635, 'y':.075}	
		id:44	
	
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.88, 'y':.075}	
		id:45

	Button:
		size_hint: .05, .05
		pos_hint: {'x':.075, 'y':.325}	
		id:26

	Button:
		size_hint: .05, .05
		pos_hint: {'x':.075, 'y':.47}	
		id:21
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.075, 'y':.62}	
		id:10
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.075, 'y':.87}	
		id:1
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.88, 'y':.325}	
		id:31
	
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.88, 'y':.47}	
		id:25
	
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.88, 'y':.62}	
		id:16
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.88, 'y':.87}	
		id:5
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.325, 'y':.87}	
		id:2
	
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.48, 'y':.87}	
		id:3
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.635, 'y':.87}	
		id:4
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.2, 'y':.75}	
		id:6
	
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.18, 'y':.58}	
		id:17
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.18, 'y':.36}	
		id:27
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.2, 'y':.20}	
		id:37
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.76, 'y':.75}	
		id:9
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.775, 'y':.58}	
		id:20
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.775, 'y':.36}	
		id:30
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.76, 'y':.20}	
		id:40
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.278, 'y':.680}	
		id:11
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.278, 'y':.55}	
		id:18
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.278, 'y':.47}	
		id:22
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.278, 'y':.4}	
		id:28
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.278, 'y':.27}	
		id:32
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.68, 'y':.671}	
		id:15
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.68, 'y':.545}	
		id:19
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.68, 'y':.465}	
		id:24
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.68, 'y':.395}	
		id:29
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.68, 'y':.268}	
		id:36
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.4, 'y':.268}	
		id:33
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.48, 'y':.268}	
		id:34
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.55, 'y':.268}	
		id:35
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.4, 'y':.671}	
		id:12
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.48, 'y':.671}	
		id:13
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.55, 'y':.671}	
		id:14
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.37, 'y':.18}	
		id:38
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.59, 'y':.18}	
		id:39
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.37, 'y':.765}	
		id:7
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.59, 'y':.765}	
		id:8
		
	Button:
		size_hint: .05, .05
		pos_hint: {'x':.477, 'y':.475}	
		id:23
''')

class RootWidget(FloatLayout):
	joueur = 1 
	pion_a_placer = 5
	def changer_couleur(self, btn):
		if self.pion_a_placer > 0:
			if btn.state == 'down' and btn.background_normal == 'img/btns/b0.png':
				if self.joueur == 1:
					btn.background_normal = 'img/btns/btn1.png'
					self.changer_joueur()
				else:
					btn.background_normal = 'img/btns/btn2.png'
					self.changer_joueur()
				self.pion_a_placer = self.pion_a_placer - 1

	def changer_joueur(self):
		if self.joueur == 1:
			self.joueur = 2
		else:
			self.joueur = 1

class MainApp(App):
    def build(self):
        return RootWidget()
    	


if __name__ == '__main__':
    MainApp().run()
